module.exports = [
"[project]/apps/web/.next-internal/server/app/shop/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=apps_web__next-internal_server_app_shop_%5Bid%5D_page_actions_9a341728.js.map