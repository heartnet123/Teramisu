var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/settings/route.js")
R.c("server/chunks/node_modules_2f0acc24._.js")
R.c("server/chunks/[root-of-the-server]__09d2326a._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_admin_settings_route_actions_715165d6.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/src/app/api/admin/settings/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/src/app/api/admin/settings/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
