(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_b32fe742._.js",
  "static/chunks/apps_web_src_8a782092._.js"
],
    source: "dynamic"
});
