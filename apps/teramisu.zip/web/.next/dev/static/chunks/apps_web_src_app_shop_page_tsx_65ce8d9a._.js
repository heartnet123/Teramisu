(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/apps_web_src_1360a21d._.js",
  "static/chunks/node_modules_b4d3f0ff._.js"
],
    source: "dynamic"
});
