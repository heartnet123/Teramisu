(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/apps_web_src_app_dashboard_dashboard_tsx_dd15b41e._.js"
],
    source: "dynamic"
});
