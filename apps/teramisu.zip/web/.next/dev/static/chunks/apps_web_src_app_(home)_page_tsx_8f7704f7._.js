(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_3b4c00c2._.js",
  "static/chunks/apps_web_src_494aaeeb._.js"
],
    source: "dynamic"
});
