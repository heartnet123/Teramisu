(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_b5191763._.js",
  "static/chunks/apps_web_src_e2f3674e._.js"
],
    source: "dynamic"
});
