(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/apps_web_src_77d306c4._.js",
  "static/chunks/node_modules_lucide-react_dist_esm_icons_28409e19._.js"
],
    source: "dynamic"
});
