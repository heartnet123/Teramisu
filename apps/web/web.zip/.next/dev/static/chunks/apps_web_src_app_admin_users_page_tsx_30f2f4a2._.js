(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/apps_web_src_8a70df3c._.js",
  "static/chunks/node_modules_33b6b2d8._.js"
],
    source: "dynamic"
});
