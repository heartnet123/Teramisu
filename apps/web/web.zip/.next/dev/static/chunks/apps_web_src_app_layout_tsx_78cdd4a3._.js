(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__4a7d5c03._.css",
  "static/chunks/node_modules_7ea0f67b._.js",
  "static/chunks/apps_web_src_a2c61b2b._.js"
],
    source: "dynamic"
});
