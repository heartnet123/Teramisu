var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/products/route.js")
R.c("server/chunks/node_modules_d921bbee._.js")
R.c("server/chunks/[root-of-the-server]__f3057800._.js")
R.c("server/chunks/apps_web__next-internal_server_app_api_products_route_actions_1e785429.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/src/app/api/products/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/apps/web/src/app/api/products/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
