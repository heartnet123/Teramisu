module.exports = [
"[project]/apps/web/.next-internal/server/app/shop/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=apps_web__next-internal_server_app_shop_page_actions_d23b8e45.js.map