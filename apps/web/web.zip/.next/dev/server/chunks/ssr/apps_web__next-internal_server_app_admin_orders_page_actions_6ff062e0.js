module.exports = [
"[project]/apps/web/.next-internal/server/app/admin/orders/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=apps_web__next-internal_server_app_admin_orders_page_actions_6ff062e0.js.map